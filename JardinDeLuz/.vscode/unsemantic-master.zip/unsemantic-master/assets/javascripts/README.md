In this folder, the following JS files are needed only to show the grid dimensions in the demo, and are otherwise not needed for Unsemantic:

* demo.js
* html5.js
* jquery.js

If you are supporting older browsers with Unsemantic, you *may* want to use the Adapt.js approach, as seen in the "adapt.html" example file.

However, if you have no need to support IE8 and lower, it is highly recommended that you use this CSS file, as it won't require JS at all.

`/assets/stylesheets/unsemantic-grid-responsive-tablet-no-ie7.css`